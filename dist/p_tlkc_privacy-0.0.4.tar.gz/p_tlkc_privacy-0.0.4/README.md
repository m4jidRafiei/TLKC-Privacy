Project that implements TLKC-privacy model for process mining
